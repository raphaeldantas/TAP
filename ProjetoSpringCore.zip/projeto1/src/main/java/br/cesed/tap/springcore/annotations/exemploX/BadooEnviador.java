package br.cesed.tap.springcore.annotations.exemploX;

import org.springframework.stereotype.Component;


@Component
public class BadooEnviador implements Enviador {

	public void enviaMensagem(String msg) {
		System.out.println("from badoo " + msg);
		
	}

}
