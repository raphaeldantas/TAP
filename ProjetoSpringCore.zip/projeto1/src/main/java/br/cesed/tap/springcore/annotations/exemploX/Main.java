package br.cesed.tap.springcore.annotations.exemploX;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Main {

	
	public static void main(String[] args) {

		ApplicationContext context = 
				new ClassPathXmlApplicationContext
				("annotations-exemplo5.xml");
		
		Aplicacao app = (Aplicacao) 
				context.getBean("App");
		
		app.enviaMensagemPadrao();		
	}
}

