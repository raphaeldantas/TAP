package br.cesed.tap.springcore.annotations.exemploX;

public interface Enviador {

	void enviaMensagem(String msg);
	 
}
