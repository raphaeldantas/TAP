package br.cesed.tap.springcore.annotations.exemploX;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

	
@Component(value="App")
public class Aplicacao {

	
	@Autowired
	@Qualifier("Tinder")
	private Enviador enviador;

	public void enviaMensagemPadrao() {
		enviador.enviaMensagem("abdul no tinder!");
	}
	
	
	public Enviador getEnviador() {
		return enviador;
	}

	public void setEnviador(Enviador enviador) {
		this.enviador = enviador;
	}
}
