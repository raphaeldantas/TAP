package br.cesed.tap.springcore.annotations.exemploX;

import org.springframework.stereotype.Component;


@Component(value="Tinder")
public class TinderEnviador implements Enviador {

	public void enviaMensagem(String msg) {
		System.out.println(msg);
		
	}

}
