package br.edu.facisa.tap.springBoot.domain;


public class Usuario {
	
	private int id;
	private String nome; 
	private String login;
	
	
	public Usuario(){
		
		
	}
	
	public Usuario(int id, String nome, String login) {
		super();
		this.id = id;
		this.nome = nome;
		this.login = login;
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getLogin() {
		return login;
	}
	
	public void setLoguin(String login) {
		this.login = login;
	}
	public String toString() {
		return "Usuario [id=" + id + ", nome=" + nome + ", login=" + login
				+ "]";
	
	
}
}