import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import Dados.Alunos;
import Negocio.GerenteDeAlunos;


public class TesteAlunos {

	private Alunos alunos;
	/* Criei um Aluno */
	
	


	GerenteDeAlunos alns = new GerenteDeAlunos();
	
	@Before 
	public void CriarAluno() {
		
	 alunos = new Alunos("1613080016", 5, "Raphael");
	
	}
	
	/* Test de Cadastro */
	@Test
	public void TestCadastro(){
		assertNotNull(alunos);
		assertNotNull(alunos.getNome());
		assertNotNull(alunos.getMatricula());
		alns.Cadastra(alunos);

	
	}
	
	/* Test de Exclus�o */
	@Test
	public void TestExclui() {
		assertNotNull(alunos);
		alns.Exclui(alunos);


	}
	
	/* Test Busca */
	@Test
	public void TestBuscaProjeto(){
		assertEquals(alunos.getNome(), "Raphael");
		
	}

	/* Testa se o Aluno esta acima do Quarto periodo */
	
	@Test
	public void TestQuartoPeriodo(){
		assertTrue(alunos.getPeriodo() >= 4);
		}
	
	/* Testa se o Aluno esta acima do Quarto periodo */
	
	@Test
	public void TesteQuartoPeriodo(){
		try {
			if (alunos.getPeriodo() < 4) {
				fail("Nao pode participar do projeto!"); 
			}
			
		}  catch (Exception e) {
			assertTrue("Pode participar!", true);
		}
	}
		
	
		/* Testa se o Aluno Possui matricula, ou se est� "vazio" */
	
		@Test
		public void TesteMatricula(){
	
				assertNotNull (alunos.getMatricula());
				
			}
		}



			
	
	


		
