package DAOS;

import Dados.Alunos;

public interface AlunosDAO {
	
	public void Cadastra(Alunos a);
	public void Exclui(Alunos a);
	public void Busca(String nome);
	public Alunos ObtemProjetoQueParticipanteParticipa(String nome); 

}
