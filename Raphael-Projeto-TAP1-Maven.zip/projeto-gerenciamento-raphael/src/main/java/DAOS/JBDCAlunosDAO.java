package DAOS;

import java.util.ArrayList;
import java.util.List;

import Dados.Alunos;


public class JBDCAlunosDAO implements AlunosDAO {
	
	 private List<Alunos> AlunosJBDC = new ArrayList<Alunos>();


		public void Cadastra(Alunos a) {
			AlunosJBDC.add(a);
			
		}


		public void Exclui(Alunos a) {
			AlunosJBDC.remove(a);
			
		}


		public void Busca(String nome) {
			for(Alunos a: AlunosJBDC){
					if(a.getNome() == nome){
						System.out.println(a.getNome());
			
		}
			}
		}


		public Alunos ObtemProjetoQueParticipanteParticipa(String nome) {
			// TODO Auto-generated method stub
			return null;
		}
}
		