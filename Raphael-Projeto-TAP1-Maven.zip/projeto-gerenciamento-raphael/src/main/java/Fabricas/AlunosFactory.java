package Fabricas;

import DAOS.AlunosDAO;
import DAOS.JBDCAlunosDAO;

public class AlunosFactory {

	
	
	public static AlunosDAO CriaInstancia(){
		return new JBDCAlunosDAO();
		
}

}