package Dados;

public class Alunos {
	
	

	private String matricula;
	private int periodo;
	private String nome;
	
	public Alunos(){
		
	}
	public Alunos(String matricula, int periodo, String nome) {
		super();

		this.matricula = matricula;
		this.periodo = periodo;
		this.nome = nome;
	}
	
	
	
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	public int getPeriodo() {
		return periodo;
	}
	public void setPeriodo(int periodo) {
		this.periodo = periodo;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}

	
	   public String toString(){
	        return "Matricula: " + this.matricula + ", Periodo: " + this.periodo + ", Nome: " + this.nome;
	
	   }
	

}
