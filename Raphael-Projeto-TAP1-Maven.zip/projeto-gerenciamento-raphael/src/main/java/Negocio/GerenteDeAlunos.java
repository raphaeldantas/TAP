package Negocio;


import DAOS.AlunosDAO;
import Dados.Alunos;
import Fabricas.AlunosFactory;

public class GerenteDeAlunos {
	
	private AlunosDAO alunosDAO = AlunosFactory.CriaInstancia();

	public void Cadastra(Alunos alunos) {
		alunosDAO.Cadastra(alunos);
	}
	
	public void Exclui(Alunos a){
		alunosDAO.Exclui(a);
	}
	public void Busca(String nome){
		alunosDAO.Busca(nome);
}
}