package br.edu.facisa.tap.springBoot.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.edu.facisa.tap.springBoot.domain.Empresa;




@RestController
@RequestMapping(value= "/Empresa")
public class EmpresaController {

	
	@RequestMapping(method = RequestMethod.GET)
	public String listarTodasEmpresas() {
		return "Todas as empresas";
	}

	@RequestMapping(value="/{identificador}", method = RequestMethod.GET)
	public String obterInformacaoEmpresa(@PathVariable String identificador) {
		return "A empresa possui o ID = " + identificador;
	}
	
	@RequestMapping(method = RequestMethod.POST)
	public String criarEmpresa(@RequestBody Empresa empresa) {

		try {
			System.out.println(empresa);
			return "foi persistido a empresa: " + empresa;

		} catch (Exception e) {
			return "problema";
		}
	}
	
	@RequestMapping(method = RequestMethod.PUT)
	public String alterarEmpresa(@RequestBody Empresa empresa) {

		try {
			System.out.println(empresa);
			return "foi alterado a empresa " + empresa;

		} catch (Exception e) {
			return "problema";
		}
	}

	@RequestMapping(value="/{identificador}", method = RequestMethod.DELETE)
	public String excluirEmpresaPorId(@PathVariable String identificador) {
		return "Ola, a empresa possui o ID = " + identificador;
}
}