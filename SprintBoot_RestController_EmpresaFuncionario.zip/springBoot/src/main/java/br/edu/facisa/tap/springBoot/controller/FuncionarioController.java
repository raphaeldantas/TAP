package br.edu.facisa.tap.springBoot.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.edu.facisa.tap.springBoot.domain.Funcionario;



@RestController
@RequestMapping(value="/Funcionario")
public class FuncionarioController {

	@RequestMapping(method = RequestMethod.GET)
	public String listarTodosFuncionarios() {
		return "Todos os funcionarios";
	}

	@RequestMapping(value="/{identificador}", method = RequestMethod.GET)
	public String obterInformacaoFuncionario(@PathVariable String identificador) {
		return "O funcionario possui o ID: = " + identificador;
	}
	
	@RequestMapping(method = RequestMethod.POST)
	public String criarFuncionario(@RequestBody Funcionario funcionario) {

		try {
			System.out.println(funcionario);
			return "foi persistido o funcionario " + funcionario;

		} catch (Exception e) {
			return "problema";
		}
	}
	
	@RequestMapping(method = RequestMethod.PUT)
	public String alterarFuncionario(@RequestBody Funcionario funcionario) {

		try {
			System.out.println(funcionario);
			return "foi alterado o funcionario " + funcionario;

		} catch (Exception e) {
			return "problema";
		}
	}

	@RequestMapping(value="/{identificador}", method = RequestMethod.DELETE)
	public String excluirFuncionarioPorId(@PathVariable String identificador) {
		return "O funcionario possui o ID: = " + identificador;
}
}
